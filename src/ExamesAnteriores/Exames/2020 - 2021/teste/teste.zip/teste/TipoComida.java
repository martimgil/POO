package teste103234;

public enum TipoComida {
    CHURRASQUEIRA,ITALIANO,MARISQUEIRA,VEGETARIANO
}
