package aula08.Ex1;

public interface IKmPercorridos {
    
    void trajeto(int quilometros);
    int ultimoTrajeto();
    int distanciaTotal();
    
}

